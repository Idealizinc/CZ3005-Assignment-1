CZ3005: Artificial Intelligence
LAB ASSIGNMENT 1: Finding a Shortest Path with An Energy Budget

Group - ILoveMDP2
Li Zhaoyuan (U2020129C)
Lim Rui An, Ryan (U2022692K)

Folder Directory
src  - Folder containing source code, run main.py to execute tasks
json - Folder containing json files to be read by source code 